kallisto quant -i  idx/mutans.idx -t 4 -b 100  -o kall_out/mutans_map/Coculture_04  fq/Coculture-04_R1_001.fastq	fq/Coculture-04_R2_001.fastq
