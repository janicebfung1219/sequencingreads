kallisto index -t 4 -i idx/mutans.idx fa/mutans_genes.fa.gz
